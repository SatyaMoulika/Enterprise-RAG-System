import { type Tone } from './tokens';
export declare const motionKinds: readonly ["embeddings", "gpu", "tokens", "vectors", "network", "attention", "agents"];
export type MotionKind = typeof motionKinds[number];
export interface AIMotionProps {
    kind: MotionKind;
    tone?: Tone;
    interaction?: 'ambient' | 'hover';
    className?: string;
    label?: string;
    decorative?: boolean;
}
export declare function AIMotion({ kind, tone, interaction, className, label, decorative }: AIMotionProps): import("react").JSX.Element;
