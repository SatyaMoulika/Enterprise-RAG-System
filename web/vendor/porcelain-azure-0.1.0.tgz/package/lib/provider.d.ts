import { type ReactNode } from 'react';
import { type ThemeOverrides } from './tokens';
export declare function ThemeProvider({ children, overrides, className }: {
    children: ReactNode;
    overrides?: ThemeOverrides;
    className?: string;
}): import("react").JSX.Element;
export declare const useMotion: () => {
    paused: boolean;
    reduced: boolean;
    toggle: () => void;
};
