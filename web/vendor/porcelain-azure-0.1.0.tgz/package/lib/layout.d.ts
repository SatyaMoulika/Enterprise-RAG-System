import type { ReactNode } from 'react';
import { type MotionKind } from './motion';
import { type Tone } from './tokens';
export interface NavigationItem {
    label: string;
    href: string;
}
export declare function Navbar({ brand, items, actions }: {
    brand: ReactNode;
    items: NavigationItem[];
    actions?: ReactNode;
}): import("react").JSX.Element;
export interface SidebarItem {
    id: string;
    label: string;
    icon?: ReactNode;
}
export declare function Sidebar({ items, active, onChange, label }: {
    items: SidebarItem[];
    active: string;
    onChange: (id: string) => void;
    label?: string;
}): import("react").JSX.Element;
export declare function DashboardShell({ sidebar, children }: {
    sidebar: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
export interface ProjectCardProps {
    title: string;
    description: string;
    category: string;
    tags: string[];
    motif: MotionKind;
    tone?: Tone;
    href: string;
    linkLabel?: string;
}
export declare function ProjectCard({ title, description, category, tags, motif, tone, href, linkLabel }: ProjectCardProps): import("react").JSX.Element;
