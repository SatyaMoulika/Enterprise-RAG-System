import type { CSSProperties } from 'react';
export declare const themeTokens: {
    readonly canvas: "#FFFFFF";
    readonly surface: "#FFFFFF";
    readonly soft: "#EFF6FC";
    readonly ink: "#243447";
    readonly muted: "#52677C";
    readonly line: "#C5D5E4";
    readonly azure: "#1769AA";
    readonly teal: "#087F8C";
    readonly violet: "#7957BD";
};
export type ThemeOverrides = Partial<Record<keyof typeof themeTokens, string>>;
export declare function themeVariables(overrides: ThemeOverrides): CSSProperties;
export declare const cx: (...values: (string | false | undefined)[]) => string;
export type Tone = 'azure' | 'teal' | 'violet';
