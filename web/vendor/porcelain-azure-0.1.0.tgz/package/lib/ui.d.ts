import { type ButtonHTMLAttributes, type AnchorHTMLAttributes, type HTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes } from 'react';
import { type Tone } from './tokens';
declare const variants: {
    primary: string;
    secondary: string;
    ghost: string;
};
export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    variant?: keyof typeof variants;
    loading?: boolean;
};
export declare function Button({ variant, loading, disabled, children, className, type, ...props }: ButtonProps): import("react").JSX.Element;
export declare function ButtonLink({ variant, className, ...props }: AnchorHTMLAttributes<HTMLAnchorElement> & {
    variant?: keyof typeof variants;
}): import("react").JSX.Element;
export declare function MotionToggle(): import("react").JSX.Element;
export declare function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>): import("react").JSX.Element;
export declare function Badge({ tone, className, ...props }: HTMLAttributes<HTMLSpanElement> & {
    tone?: Tone;
}): import("react").JSX.Element;
export declare function Eyebrow({ className, ...props }: HTMLAttributes<HTMLParagraphElement>): import("react").JSX.Element;
export declare function Section({ eyebrow, title, children, id, className }: {
    eyebrow: string;
    title: ReactNode;
    children: ReactNode;
    id?: string;
    className?: string;
}): import("react").JSX.Element;
export declare function InputField({ label, hint, error, id, ...props }: InputHTMLAttributes<HTMLInputElement> & {
    label: string;
    hint?: string;
    error?: string;
}): import("react").JSX.Element;
export declare function SelectField({ label, children, id, ...props }: SelectHTMLAttributes<HTMLSelectElement> & {
    label: string;
}): import("react").JSX.Element;
export declare function StatCard({ label, value }: {
    label: string;
    value: ReactNode;
}): import("react").JSX.Element;
export {};
